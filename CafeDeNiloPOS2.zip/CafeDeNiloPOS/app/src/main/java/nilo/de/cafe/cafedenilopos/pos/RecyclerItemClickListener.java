package nilo.de.cafe.cafedenilopos.pos;


import nilo.de.cafe.cafedenilopos.models.Products;

public interface RecyclerItemClickListener {
    void onItemClick(Products products);
}